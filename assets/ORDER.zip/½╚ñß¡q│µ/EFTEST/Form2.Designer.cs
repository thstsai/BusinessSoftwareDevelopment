﻿namespace EFTEST
{
  partial class Form2
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.訂單DataGridView = new System.Windows.Forms.DataGridView();
      this.訂單BindingSource = new System.Windows.Forms.BindingSource(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.訂單DataGridView)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.訂單BindingSource)).BeginInit();
      this.SuspendLayout();
      // 
      // 訂單DataGridView
      // 
      this.訂單DataGridView.AllowUserToAddRows = false;
      this.訂單DataGridView.AllowUserToDeleteRows = false;
      this.訂單DataGridView.AutoGenerateColumns = false;
      this.訂單DataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
      this.訂單DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.訂單DataGridView.DataSource = this.訂單BindingSource;
      this.訂單DataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.訂單DataGridView.Location = new System.Drawing.Point(0, 0);
      this.訂單DataGridView.Name = "訂單DataGridView";
      this.訂單DataGridView.ReadOnly = true;
      this.訂單DataGridView.RowTemplate.Height = 31;
      this.訂單DataGridView.Size = new System.Drawing.Size(578, 344);
      this.訂單DataGridView.TabIndex = 1;
      // 
      // Form2
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(578, 344);
      this.Controls.Add(this.訂單DataGridView);
      this.Name = "Form2";
      this.Text = "訂單明細";
      ((System.ComponentModel.ISupportInitialize)(this.訂單DataGridView)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.訂單BindingSource)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.BindingSource 訂單BindingSource;
    private System.Windows.Forms.DataGridView 訂單DataGridView;
  }
}