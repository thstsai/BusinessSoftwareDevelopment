﻿namespace EFTEST
{
  partial class Form1
  {
    /// <summary>
    /// 設計工具所需的變數。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// 清除任何使用中的資源。
    /// </summary>
    /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form 設計工具產生的程式碼

    /// <summary>
    /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
    /// 這個方法的內容。
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.Label 公司名稱Label;
      System.Windows.Forms.Label 地址Label;
      System.Windows.Forms.Label 性別Label;
      System.Windows.Forms.Label 客戶編號Label;
      System.Windows.Forms.Label 連絡人Label;
      System.Windows.Forms.Label 照片檔名Label;
      System.Windows.Forms.Label 職稱Label;
      System.Windows.Forms.Label 訂單數Label;
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dataGridView1 = new System.Windows.Forms.DataGridView();
      this.客戶BindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.公司名稱TextBox = new System.Windows.Forms.TextBox();
      this.地址TextBox = new System.Windows.Forms.TextBox();
      this.性別TextBox = new System.Windows.Forms.TextBox();
      this.客戶編號TextBox = new System.Windows.Forms.TextBox();
      this.連絡人TextBox = new System.Windows.Forms.TextBox();
      this.照片檔名TextBox = new System.Windows.Forms.TextBox();
      this.職稱TextBox = new System.Windows.Forms.TextBox();
      this.照片PictureBox = new System.Windows.Forms.PictureBox();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button9 = new System.Windows.Forms.Button();
      this.訂單數TextBox = new System.Windows.Forms.TextBox();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.button10 = new System.Windows.Forms.Button();
      公司名稱Label = new System.Windows.Forms.Label();
      地址Label = new System.Windows.Forms.Label();
      性別Label = new System.Windows.Forms.Label();
      客戶編號Label = new System.Windows.Forms.Label();
      連絡人Label = new System.Windows.Forms.Label();
      照片檔名Label = new System.Windows.Forms.Label();
      職稱Label = new System.Windows.Forms.Label();
      訂單數Label = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.客戶BindingSource)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.照片PictureBox)).BeginInit();
      this.SuspendLayout();
      // 
      // 公司名稱Label
      // 
      公司名稱Label.AutoSize = true;
      公司名稱Label.Location = new System.Drawing.Point(379, 51);
      公司名稱Label.Name = "公司名稱Label";
      公司名稱Label.Size = new System.Drawing.Size(85, 18);
      公司名稱Label.TabIndex = 1;
      公司名稱Label.Text = "公司名稱:";
      // 
      // 地址Label
      // 
      地址Label.AutoSize = true;
      地址Label.Location = new System.Drawing.Point(379, 226);
      地址Label.Name = "地址Label";
      地址Label.Size = new System.Drawing.Size(49, 18);
      地址Label.TabIndex = 3;
      地址Label.Text = "地址:";
      // 
      // 性別Label
      // 
      性別Label.AutoSize = true;
      性別Label.Location = new System.Drawing.Point(379, 156);
      性別Label.Name = "性別Label";
      性別Label.Size = new System.Drawing.Size(49, 18);
      性別Label.TabIndex = 5;
      性別Label.Text = "性別:";
      // 
      // 客戶編號Label
      // 
      客戶編號Label.AutoSize = true;
      客戶編號Label.Location = new System.Drawing.Point(379, 16);
      客戶編號Label.Name = "客戶編號Label";
      客戶編號Label.Size = new System.Drawing.Size(85, 18);
      客戶編號Label.TabIndex = 7;
      客戶編號Label.Text = "客戶編號:";
      // 
      // 連絡人Label
      // 
      連絡人Label.AutoSize = true;
      連絡人Label.Location = new System.Drawing.Point(379, 86);
      連絡人Label.Name = "連絡人Label";
      連絡人Label.Size = new System.Drawing.Size(67, 18);
      連絡人Label.TabIndex = 9;
      連絡人Label.Text = "連絡人:";
      // 
      // 照片檔名Label
      // 
      照片檔名Label.AutoSize = true;
      照片檔名Label.Location = new System.Drawing.Point(379, 261);
      照片檔名Label.Name = "照片檔名Label";
      照片檔名Label.Size = new System.Drawing.Size(85, 18);
      照片檔名Label.TabIndex = 11;
      照片檔名Label.Text = "照片檔名:";
      // 
      // 職稱Label
      // 
      職稱Label.AutoSize = true;
      職稱Label.Location = new System.Drawing.Point(379, 121);
      職稱Label.Name = "職稱Label";
      職稱Label.Size = new System.Drawing.Size(49, 18);
      職稱Label.TabIndex = 13;
      職稱Label.Text = "職稱:";
      // 
      // 訂單數Label
      // 
      訂單數Label.AutoSize = true;
      訂單數Label.Location = new System.Drawing.Point(379, 192);
      訂單數Label.Name = "訂單數Label";
      訂單數Label.Size = new System.Drawing.Size(67, 18);
      訂單數Label.TabIndex = 16;
      訂單數Label.Text = "訂單數:";
      // 
      // dataGridView1
      // 
      this.dataGridView1.AllowUserToAddRows = false;
      this.dataGridView1.AllowUserToDeleteRows = false;
      this.dataGridView1.AutoGenerateColumns = false;
      this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
      dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle10.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
      dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
      this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.DataSource = this.客戶BindingSource;
      dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle11.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
      dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle11;
      this.dataGridView1.Location = new System.Drawing.Point(13, 13);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.ReadOnly = true;
      dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle12.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
      dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
      this.dataGridView1.RowTemplate.Height = 31;
      this.dataGridView1.Size = new System.Drawing.Size(350, 274);
      this.dataGridView1.TabIndex = 0;
      // 
      // 公司名稱TextBox
      // 
      this.公司名稱TextBox.Location = new System.Drawing.Point(470, 48);
      this.公司名稱TextBox.Name = "公司名稱TextBox";
      this.公司名稱TextBox.Size = new System.Drawing.Size(100, 29);
      this.公司名稱TextBox.TabIndex = 2;
      // 
      // 地址TextBox
      // 
      this.地址TextBox.Location = new System.Drawing.Point(470, 223);
      this.地址TextBox.Name = "地址TextBox";
      this.地址TextBox.Size = new System.Drawing.Size(286, 29);
      this.地址TextBox.TabIndex = 4;
      // 
      // 性別TextBox
      // 
      this.性別TextBox.Location = new System.Drawing.Point(470, 153);
      this.性別TextBox.Name = "性別TextBox";
      this.性別TextBox.Size = new System.Drawing.Size(100, 29);
      this.性別TextBox.TabIndex = 6;
      // 
      // 客戶編號TextBox
      // 
      this.客戶編號TextBox.Location = new System.Drawing.Point(470, 13);
      this.客戶編號TextBox.Name = "客戶編號TextBox";
      this.客戶編號TextBox.Size = new System.Drawing.Size(100, 29);
      this.客戶編號TextBox.TabIndex = 8;
      // 
      // 連絡人TextBox
      // 
      this.連絡人TextBox.Location = new System.Drawing.Point(470, 83);
      this.連絡人TextBox.Name = "連絡人TextBox";
      this.連絡人TextBox.Size = new System.Drawing.Size(100, 29);
      this.連絡人TextBox.TabIndex = 10;
      // 
      // 照片檔名TextBox
      // 
      this.照片檔名TextBox.Location = new System.Drawing.Point(470, 258);
      this.照片檔名TextBox.Name = "照片檔名TextBox";
      this.照片檔名TextBox.Size = new System.Drawing.Size(189, 29);
      this.照片檔名TextBox.TabIndex = 12;
      // 
      // 職稱TextBox
      // 
      this.職稱TextBox.Location = new System.Drawing.Point(470, 118);
      this.職稱TextBox.Name = "職稱TextBox";
      this.職稱TextBox.Size = new System.Drawing.Size(100, 29);
      this.職稱TextBox.TabIndex = 14;
      // 
      // 照片PictureBox
      // 
      this.照片PictureBox.Location = new System.Drawing.Point(576, 12);
      this.照片PictureBox.Name = "照片PictureBox";
      this.照片PictureBox.Size = new System.Drawing.Size(180, 205);
      this.照片PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.照片PictureBox.TabIndex = 16;
      this.照片PictureBox.TabStop = false;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(15, 297);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(83, 33);
      this.button1.TabIndex = 18;
      this.button1.Text = "第一筆";
      this.button1.UseVisualStyleBackColor = true;
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(193, 297);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(83, 33);
      this.button2.TabIndex = 19;
      this.button2.Text = "上一筆";
      this.button2.UseVisualStyleBackColor = true;
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(104, 297);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(83, 33);
      this.button3.TabIndex = 20;
      this.button3.Text = "下一筆";
      this.button3.UseVisualStyleBackColor = true;
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(282, 297);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(83, 33);
      this.button4.TabIndex = 21;
      this.button4.Text = "最末筆";
      this.button4.UseVisualStyleBackColor = true;
      // 
      // button5
      // 
      this.button5.Location = new System.Drawing.Point(673, 297);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(83, 33);
      this.button5.TabIndex = 25;
      this.button5.Text = "結束";
      this.button5.UseVisualStyleBackColor = true;
      // 
      // button6
      // 
      this.button6.Location = new System.Drawing.Point(576, 297);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(83, 33);
      this.button6.TabIndex = 24;
      this.button6.Text = "更新";
      this.button6.UseVisualStyleBackColor = true;
      // 
      // button7
      // 
      this.button7.Location = new System.Drawing.Point(479, 297);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(83, 33);
      this.button7.TabIndex = 23;
      this.button7.Text = "刪除";
      this.button7.UseVisualStyleBackColor = true;
      // 
      // button8
      // 
      this.button8.Location = new System.Drawing.Point(382, 297);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(83, 33);
      this.button8.TabIndex = 22;
      this.button8.Text = "新增";
      this.button8.UseVisualStyleBackColor = true;
      // 
      // button9
      // 
      this.button9.Location = new System.Drawing.Point(673, 258);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(83, 33);
      this.button9.TabIndex = 26;
      this.button9.Text = "開啟";
      this.button9.UseVisualStyleBackColor = true;
      // 
      // 訂單數TextBox
      // 
      this.訂單數TextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.訂單數TextBox.Location = new System.Drawing.Point(470, 188);
      this.訂單數TextBox.Name = "訂單數TextBox";
      this.訂單數TextBox.ReadOnly = true;
      this.訂單數TextBox.Size = new System.Drawing.Size(63, 29);
      this.訂單數TextBox.TabIndex = 27;
      this.訂單數TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // openFileDialog1
      // 
      this.openFileDialog1.FileName = "openFileDialog1";
      // 
      // button10
      // 
      this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.button10.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
      this.button10.Location = new System.Drawing.Point(539, 188);
      this.button10.Name = "button10";
      this.button10.Size = new System.Drawing.Size(31, 29);
      this.button10.TabIndex = 28;
      this.button10.Text = "...";
      this.button10.UseVisualStyleBackColor = false;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(773, 347);
      this.Controls.Add(this.button10);
      this.Controls.Add(this.訂單數TextBox);
      this.Controls.Add(this.button9);
      this.Controls.Add(this.button5);
      this.Controls.Add(this.button6);
      this.Controls.Add(this.button7);
      this.Controls.Add(this.button8);
      this.Controls.Add(this.button4);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.button1);
      this.Controls.Add(訂單數Label);
      this.Controls.Add(this.照片PictureBox);
      this.Controls.Add(公司名稱Label);
      this.Controls.Add(this.公司名稱TextBox);
      this.Controls.Add(地址Label);
      this.Controls.Add(this.地址TextBox);
      this.Controls.Add(性別Label);
      this.Controls.Add(this.性別TextBox);
      this.Controls.Add(客戶編號Label);
      this.Controls.Add(this.客戶編號TextBox);
      this.Controls.Add(連絡人Label);
      this.Controls.Add(this.連絡人TextBox);
      this.Controls.Add(照片檔名Label);
      this.Controls.Add(this.照片檔名TextBox);
      this.Controls.Add(職稱Label);
      this.Controls.Add(this.職稱TextBox);
      this.Controls.Add(this.dataGridView1);
      this.Name = "Form1";
      this.Text = "客戶瀏覽";
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.客戶BindingSource)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.照片PictureBox)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dataGridView1;
    private System.Windows.Forms.BindingSource 客戶BindingSource;
    private System.Windows.Forms.TextBox 公司名稱TextBox;
    private System.Windows.Forms.TextBox 地址TextBox;
    private System.Windows.Forms.TextBox 性別TextBox;
    private System.Windows.Forms.TextBox 客戶編號TextBox;
    private System.Windows.Forms.TextBox 連絡人TextBox;
    private System.Windows.Forms.TextBox 照片檔名TextBox;
    private System.Windows.Forms.TextBox 職稱TextBox;
    private System.Windows.Forms.PictureBox 照片PictureBox;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.Button button9;
    private System.Windows.Forms.TextBox 訂單數TextBox;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private System.Windows.Forms.Button button10;
  }
}

